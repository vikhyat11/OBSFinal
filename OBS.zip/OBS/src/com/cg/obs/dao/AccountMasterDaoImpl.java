package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.obs.dto.AccountMaster;
import com.cg.obs.exception.BankException;
import com.cg.obs.util.DBUtil;

//This class contains the methods implemented for Account Master table
public class AccountMasterDaoImpl implements AccountMasterDao
{
	Logger accountLogger= null;
	Connection con;
	Statement st;
	PreparedStatement pst;
	CustomerDao cusDao;
	UserTableDao userDao;
	public AccountMasterDaoImpl() {
		super();
		accountLogger= Logger.getLogger(AccountMasterDaoImpl.class);
	    PropertyConfigurator.configure("log4j.properties");
		con=DBUtil.getconnection();
		cusDao=new CustomerDaoImpl();
		userDao=new UserTableDaoImpl();
	}
	//a new account is created
	@Override
	public boolean addAccount(int uid,String custName, String custEmail,
			String custAddr, String custPAN, String custPwd, String custQues,
			String custTPwd, String accType, long custMob, double balance) throws BankException {
		try {
			accountLogger.info("Adding new account");
			pst=con.prepareStatement(QueryMapper.CREATE_ACCOUNT);
			pst.setString(1, accType);
			pst.setDouble(2, balance);
			long accId=0;
			accountLogger.warn("Account being added");
			int upd=pst.executeUpdate();
			accountLogger.debug("New account added in account master");
			if(upd>0)
			{
				st=con.createStatement();
				accountLogger.warn("Fetching account number");
				ResultSet rs=st.executeQuery(QueryMapper.GET_CURR_ACCID);
				while(rs.next())
				{
					accId=rs.getLong(1);
				}
			}
			else
			{
				return false;
			}
			cusDao.addCustomer(custName, custEmail, custAddr, custPAN, custMob, accId);
			accountLogger.debug("New account added in customer");
			userDao.addUser(uid,custPwd, custQues, custTPwd, accId);
			accountLogger.debug("New account added in user");
		} catch (SQLException e) {
			accountLogger.fatal("Bank Exception occured");
			throw new BankException("Exception occured while adding new account");
		}
		return true;
	}
	//method for retrieving balance
	public ArrayList<AccountMaster> getBalance(long  uid) throws BankException {
		ArrayList<AccountMaster> al = new ArrayList<AccountMaster>();	
			try {
				accountLogger.info("Fetching account balance");
				long acc=0;
				ArrayList<Long> accIds=new ArrayList<Long>();
				PreparedStatement pst1=con.prepareStatement(QueryMapper.FETCH_ACCID);
				pst1.setLong(1, uid);
				accountLogger.warn("Obtaining all accounts");
				ResultSet rs1=pst1.executeQuery();
				accountLogger.debug("Account Numbers for the user is fetched");
				while(rs1.next()) {
					acc=rs1.getLong(1);
					accIds.add(acc);
				}
				for(long var:accIds)
				{
				pst=con.prepareStatement(QueryMapper.GET_BALANCE);
				pst.setLong(1, var);
				accountLogger.warn("Obtaining balance for all accounts");
				ResultSet rs=pst.executeQuery();
				accountLogger.debug("Account balance fetched for all accounts for the user");
						while(rs.next())
						{
							int balance = rs.getInt(1);
							al.add(new AccountMaster(var, "", balance,null));
						}
						
						
				}
			} catch (SQLException e) {
				accountLogger.fatal("Bank Exception occured");
				throw new BankException("Exception occured while obtaining balance");
			}
		
		return al;
	}
}
