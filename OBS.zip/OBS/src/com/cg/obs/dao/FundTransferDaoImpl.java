package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.obs.dto.AccountMaster;
import com.cg.obs.dto.FundTransfer;
import com.cg.obs.exception.BankException;
import com.cg.obs.util.DBUtil;
//This class contains the methods implemented for Transactions table
public class FundTransferDaoImpl implements FundTransferDao
{
	Logger fundLogger;
	static Connection con=DBUtil.getconnection();
	Statement st;
	PreparedStatement pst;
	//method to transfer to self account
	public boolean transferToSelf(long debitAcc, long creditAcc, int amt)throws BankException
	{	
		fundLogger.info("Transfering amount");
		LocalDate today = LocalDate.now();
		int dataInserted = 0;
		int dataInsertedBal1 = 0;
		int dataInsertedBal2 = 0;
		java.sql.Date sqlToday = java.sql.Date.valueOf(today);
		int currDebBal=0;
		int currCreBal=0;
		String tod=today.toString();
		try{
			fundLogger.info("Obtaining balance for the account to be debited");
			pst = con.prepareStatement(QueryMapper.GET_BALANCE);
			pst.setLong(1, debitAcc);
			fundLogger.warn("getting debitAcc balance");
			ResultSet rs = pst.executeQuery();
			fundLogger.debug("debitAcc balance obtained");
			while(rs.next())
			{
				currDebBal = rs.getInt(1);
			}
			
			fundLogger.debug("Obtaining balance for the account to be credited");
			pst = con.prepareStatement(QueryMapper.GET_BALANCE);
			pst.setLong(1, creditAcc);
			fundLogger.warn("getting creditAcc balance");
			ResultSet rs1 = pst.executeQuery();
			fundLogger.debug("creditAcc balance obtained");
			while(rs1.next())
			{
				currCreBal = rs1.getInt(1);
			}
			
			if(currDebBal>=amt)
			{
				fundLogger.warn("Current balance is greater than that of withdraw amount");
				currDebBal = currDebBal - amt;
				currCreBal = currCreBal + amt;
				pst = con.prepareStatement(QueryMapper.UPDATE_BALANCE);
				pst.setInt(1, currDebBal);
				pst.setLong(2, debitAcc);
				fundLogger.warn("updating debitAcc balance");
				dataInsertedBal1 = pst.executeUpdate();
				pst = con.prepareStatement(QueryMapper.UPDATE_BALANCE);
				pst.setInt(1, currCreBal);
				pst.setLong(2, creditAcc);
				fundLogger.warn("updating creditAcc balance");
				dataInsertedBal2 = pst.executeUpdate();
				
				pst = con.prepareStatement(QueryMapper.ADD_TRANSFER);
				pst.setLong(1,debitAcc);
				pst.setLong(2,creditAcc);
				pst.setDate(3,sqlToday);
				pst.setInt(4,amt);
				dataInserted = pst.executeUpdate();
				
				pst = con.prepareStatement(QueryMapper.ADD_TRANSACTION);
				pst.setString(1,"Account debited");
				fundLogger.info("Account debited");
				pst.setString(2,tod);
				pst.setString(3,"D");
				pst.setInt(4,amt);
				pst.setLong(5,debitAcc);
				fundLogger.warn("Adding transaction");
				dataInserted = pst.executeUpdate();
				
				pst = con.prepareStatement(QueryMapper.ADD_TRANSACTION);
				pst.setString(1,"Account credited");
				fundLogger.info("Account Credited");
				pst.setString(2,tod);
				pst.setString(3,"C");
				pst.setInt(4,amt);
				pst.setLong(5,creditAcc);
				fundLogger.warn("Adding transaction");
				dataInserted = pst.executeUpdate();
				fundLogger.debug("Fund transfer done");
			}
			else
			{
				throw new Exception("Insufficient Balance!");
			}	
		}
		catch(Exception e)
		{
			fundLogger.fatal("Bank Exception");
			throw new BankException("Exception occured while transfering amount to self");
		}
		
		if(dataInserted==1 || dataInsertedBal1==1 || dataInsertedBal2==1)
			return true;
		else
			return false;
	}
	//constructor to define objects
	public FundTransferDaoImpl() {
		super();
		fundLogger= Logger.getLogger(FundTransferDaoImpl.class);
	    PropertyConfigurator.configure("log4j.properties");
	}


}
