package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.obs.dto.AccountMaster;
import com.cg.obs.dto.Customer;
import com.cg.obs.exception.BankException;
import com.cg.obs.util.DBUtil;
//This class contains the methods implemented for Customer table

public class CustomerDaoImpl implements CustomerDao
{	Logger custLogger=null;
	static Connection con=DBUtil.getconnection();
	Statement st;
	PreparedStatement pst;
	
	//Method for adding customer
	@Override
	public void addCustomer(String custName, String custEmail, String custAddr, String custPAN, long custMob, long accId) throws BankException
	{
		try {
			custLogger.info("adding new Customer");
			System.out.println(custName+custEmail+custAddr+custPAN+custMob+accId);
			pst=con.prepareStatement(QueryMapper.CREATE_ACCOUNT_CUSTOMER);
			pst.setLong(1, accId);
			pst.setString(2, custName);
			pst.setString(3, custEmail);
			pst.setString(4, custAddr);
			pst.setString(5, custPAN);
			pst.setLong(6, custMob);
			custLogger.warn("New Customer being added");
			pst.executeUpdate();
			custLogger.debug("New Customer added");
			
		} catch (SQLException e) {
			custLogger.fatal("Bank Exception occured");
			throw new BankException("Exception occured while adding new customers");
		}
		
	}

//method for updating the mobile number
	@Override
	public boolean updateMobile(long accNo, long new_number) throws BankException {
		try {
			custLogger.info("updating mobile number");
			pst=con.prepareStatement(QueryMapper.UPDATE_MOBILE);
			pst.setLong(1, new_number);
			pst.setLong(2, accNo);
			custLogger.warn("Mobile Number being added");
			int upd=pst.executeUpdate();
			custLogger.debug("Mobile number updated");
			if(upd>0)
				return true;
		} catch (SQLException e) {
			custLogger.fatal("Bank Exception occured");
			throw new BankException("Exception occured while updating mobile number");
		}
		return false;
	}


	//method for updating address
	@Override
	public boolean updateAddress(long accNo, String address) throws BankException {
		try {
			custLogger.info("Updating address ");
			pst=con.prepareStatement(QueryMapper.UPDATE_ADDRESS);
			pst.setString(1, address);
			pst.setLong(2, accNo);
			custLogger.warn("Address being added");
			int upd=pst.executeUpdate();
			custLogger.debug("Address updated");
			if(upd>0)
				return true;
		} catch (SQLException e) {
			custLogger.fatal("Bank Exception occured");
			throw new BankException("Exception occured while updating address");
		}
		return false;
	}


	//method for fetching the mobile number
	@Override
	public long getMobile(long accNo) throws BankException {
		long mob=0;
		try {
			custLogger.info("Fetching mobile number");
			pst=con.prepareStatement(QueryMapper.GET_MOBILE);
			pst.setLong(1, accNo);
			custLogger.warn("Mobile Number being fetched");
			ResultSet rs=pst.executeQuery();
			custLogger.debug("Mobile Number retrieved");
			while(rs.next())
			{
				mob = rs.getLong(1);
			}
		} catch (SQLException e) {
			custLogger.fatal("Bank Exception occured");
			throw new BankException("Exception occured while fetching old mobile number");
		}
		return mob;
	}

	//method for fetching the address
	@Override
	public String getAddress(long accNo) throws BankException {
		String addr="";
		try {
			custLogger.info("Fetching address");
			pst=con.prepareStatement(QueryMapper.GET_ADDRESS);
			pst.setLong(1, accNo);
			custLogger.warn("Address being fetched");
			ResultSet rs=pst.executeQuery();
			custLogger.debug("Address retrieved");
			while(rs.next())
			{
				addr = rs.getString(1);
			}
		} catch (SQLException e) {
			custLogger.fatal("Bank Exception occured");
			throw new BankException("Exception occured while fetching old address");
		}
		return addr;
	}


	public CustomerDaoImpl() {
		super();
		custLogger= Logger.getLogger(CustomerDaoImpl.class);
	    PropertyConfigurator.configure("log4j.properties");
	}




}
