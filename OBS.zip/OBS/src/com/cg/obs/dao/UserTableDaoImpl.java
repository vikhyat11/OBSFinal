package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.obs.dto.AccountMaster;
import com.cg.obs.dto.UserTable;
import com.cg.obs.exception.BankException;
import com.cg.obs.util.DBUtil;
//This class contains the methods implemented for User table
public class UserTableDaoImpl implements UserTableDao
{
	Logger userLogger;
	static Connection con=DBUtil.getconnection();
	Statement st;
	PreparedStatement pst;
	static int counter=0;
	//Method to validate Login
	@Override
	public boolean validateLogin(int uId, String pwd) throws BankException{
		try {
			userLogger.info("Validating User");
			pst=con.prepareStatement(QueryMapper.LOGIN_VALIDATION);
			pst.setInt(1, uId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String pass=rs.getString(3);
				String getlock=rs.getString(6);
				int lock = Integer.parseInt(getlock);
				if(lock == 3)
					return false;
				else
				{
					if(pass.equals(pwd))
					{
						userLogger.info("Correct Password");
						PreparedStatement pst1=con.prepareStatement(QueryMapper.SET_LOCK_STATUS);
						pst1.setString(1,"0");
						pst1.setInt(2, uId);
						pst1.executeUpdate();
						return true;
					}
					else
					{	
						if(lock<3)
							
						{	
							userLogger.warn("Incorrect password");
								lock++;
								String updateLock = ""+lock;
								PreparedStatement pst1=con.prepareStatement(QueryMapper.SET_LOCK_STATUS);
								pst1.setString(1,updateLock);
								pst1.setInt(2, uId);
								pst1.executeUpdate();
						}	
						return false;
					}
				}
			}
		} catch (SQLException e) {
			userLogger.fatal("Bank Exception occured");
			throw new BankException("Exception while validating user");
		}
		
		return false;
	}
	
	
	//Method to reset password
	@Override
	public boolean resetPassword(int uId, String ques) throws BankException {
		try {
			userLogger.info("Reset password");
			pst=con.prepareStatement(QueryMapper.RESET_PWD);
			pst.setInt(1, uId);
			String ans="";
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				ans=rs.getString(1);
			}
			if(ans.equalsIgnoreCase(ques))
			{
				PreparedStatement pst1=con.prepareStatement(QueryMapper.CHANGE_PWD);
				pst1.setString(1, "sbq500#");
				pst.setInt(2, uId);
				int upd = pst1.executeUpdate();
				if(upd>0)
					return true;
			}
		} catch (SQLException e) {
			userLogger.fatal("Bank Exception occured");
			throw new BankException("Reset Password Exception");
		}
		return false;
	}
	//Method to add user in table
	public boolean addUser(int uid,String custPwd, String custQues, String custTPwd, long accId) throws BankException
	{
			
		try {
			userLogger.debug("Creating new user");
			pst=con.prepareStatement(QueryMapper.CREATE_ACCOUNT_USER_TABLE);
			pst.setLong(1, accId);
			pst.setInt(2, uid);
			pst.setString(3, custPwd);
			pst.setString(4, custQues);
			pst.setString(5, custTPwd);
			pst.setString(6, "0");
			int upd=pst.executeUpdate();
			if(upd>0)
				return true;
		} catch (SQLException e) {
			userLogger.fatal("Bank Exception occured");
			throw new BankException("Exception while adding user");
		}
		return false;
	}
	
	
	
	//Get Accounts

	public ArrayList<Long> getAccounts(int uId)throws BankException
	{
		ArrayList<Long> list = new ArrayList<Long>();
		try{
			userLogger.debug("Fetching user accounts");
			pst = con.prepareStatement(QueryMapper.GET_ACCOUNTS);
			pst.setInt(1, uId);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				list.add(rs.getLong(1));
			}
		}
		catch(Exception e)
		{
			userLogger.fatal("Bank Exception occured");
			throw new BankException("Exception occured while fetching accounts");
		}
		
		return list;
	}

	public boolean changePwd(int user_id, String newPwd)throws BankException
	{
		int dataInserted = 0;
		try{
			userLogger.debug("Resetting password ");
		pst = con.prepareStatement(QueryMapper.CHANGE_PWD);
		pst.setString(1, newPwd);
		pst.setInt(2, user_id);
		dataInserted = pst.executeUpdate();
		}
		catch(Exception e){
			userLogger.fatal("Bank Exception occured");
			throw new BankException("Exception occured while changing password");
		}
		
		if(dataInserted>0)
			return true;
		else
			return false;
	}



	//Method to validate Password
	@Override
	public boolean validateOldPassword(int uId, String pwd) throws BankException {
		try {
			userLogger.debug("Validating old password");
			pst=con.prepareStatement(QueryMapper.PASSWORD_VALIDATION);
			pst.setInt(1, uId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String pass=rs.getString(1);

					if(pass.equals(pwd))
					{
						return true;
					}				
			}
		} 
		catch (SQLException e) {
			userLogger.fatal("Bank Exception occured");
			throw new BankException("Password Validation Exception");
		}
		
		return false;
	}



	//Method to validate Security question
	@Override
	public boolean validateSecurityQuestion(String secAns, int uId) throws BankException {
		try
		{
			userLogger.debug("Validating Security question");
			pst=con.prepareStatement(QueryMapper.SECRET_QUESTION_VALIDATION);
			pst.setInt(1, uId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String securityAns = rs.getString(1);

					if((securityAns).toLowerCase().equals(secAns.toLowerCase()))
					{
						return true;
					}				
			}
		}
		catch(SQLException e)
		{
			userLogger.fatal("Bank Exception occured");
			throw new BankException("Exception occured while validating security question");
		}
		return false;
	}



	//Method to validate Lock Status
	@Override
	public boolean validateLockStatus(int uId) throws BankException {
		
		try
		{
			userLogger.debug("Validating lock status");
			pst=con.prepareStatement(QueryMapper.GET_LOCK_STATUS);
			pst.setInt(1, uId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String lockStatus = rs.getString(1);
				int lock = Integer.parseInt(lockStatus);
					if(lock < 3)
					{
						return true;
					}				
					else
					{	
						userLogger.info("Account is locked");
						userLogger.fatal("Bank Exception occured");
						throw new BankException("Oops!!!Your Account is locked...");
					}
			}
		}
		catch(SQLException e)
		{
			userLogger.fatal("Bank Exception occured");
			throw new BankException("Exception while validating lock status");
		}
		return false;

	}

	//method to validate Transaction password

	@Override
	public boolean validateTransPwd(long fromAccNo, String tranPwd)throws BankException {
		try
		{
			pst=con.prepareStatement(QueryMapper.GET_TRAN_PWD);
			pst.setLong(1, fromAccNo);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String foundTranPwd = rs.getString(1);
				if(foundTranPwd.equals(tranPwd)) {
					return true;
				}
			}
			return false;
		}
		catch(SQLException e)
		{
			userLogger.fatal("Bank Exception occured");
			throw new BankException("Validating transaction password exception");
		}
	}



	public UserTableDaoImpl() {
		userLogger= Logger.getLogger(UserTableDaoImpl.class);
	    PropertyConfigurator.configure("log4j.properties");
	} 
}
