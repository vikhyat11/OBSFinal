package com.cg.obs.dao;

import com.cg.obs.exception.BankException;
//The interface for transactions table functionalities
public interface FundTransferDao
{
	public boolean transferToSelf(long debitAcc, long creditAcc, int amt)throws BankException;
}
