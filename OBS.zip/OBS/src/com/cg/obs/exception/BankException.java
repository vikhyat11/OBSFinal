package com.cg.obs.exception;

public class BankException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String msg;
	public BankException() {
		super();
	}

	public BankException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public BankException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public BankException(String arg0) {
		super(arg0);
		this.msg = arg0;
	}

	public BankException(Throwable arg0) {
		super(arg0);
	}
	
	

	@Override
	public String toString() {
		return "BankException....." + msg;
	}

}
