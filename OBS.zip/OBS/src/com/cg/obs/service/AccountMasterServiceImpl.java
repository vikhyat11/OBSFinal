package com.cg.obs.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.obs.dao.AccountMasterDaoImpl;
import com.cg.obs.dto.AccountMaster;
import com.cg.obs.exception.BankException;
//Contains All the validations for the Account master database.
public class AccountMasterServiceImpl implements AccountMasterService {

	AccountMasterDaoImpl dao;
	public AccountMasterServiceImpl() {
		dao = new AccountMasterDaoImpl();	
	}

	@Override
	public boolean addAccount(int uid,String custName, String custEmail, String custAddr, String custPAN, String custPwd,
			String custQues, String custTPwd, String accType, long custMob, double balance) throws BankException {
		
		return dao.addAccount(uid,custName, custEmail, custAddr, custPAN, custPwd, custQues, custTPwd, accType, custMob, balance);
	}

	@Override
	public ArrayList<AccountMaster> getBalance(long uid) throws BankException {
		
		return dao.getBalance(uid);
	}

	@Override
	public boolean validateUserId(int uId) {
		String userId = new Integer(uId).toString();
		String uIdPattern = "[0-9]{6}";
		if(Pattern.matches(uIdPattern, userId))
			return true;
		else
			return false;
		
	}
	
	@Override
	public boolean validatePassword(String custPwd) {
		String pwdPattern = "((?=.*\\d)(?=.*[a-z])(?=.*[@#$%]).{6,20})";
		if(Pattern.matches(pwdPattern, custPwd))
		{
			return true;
		}
		else
		  return false;
	}
	
	/* (    # Start of group
 	(?=.*\d)		#   must contains one digit from 0-9
	(?=.*[a-z])		#   must contains one lowercase characters
	(?=.*[@#$%])		#   must contains one special symbols in the list "@#$%"
	 .		#     match anything with previous condition checking
	{6,20}	#        length at least 6 characters and maximum of 20	
	)
*/

	@Override
	public boolean validateMail(String custEmail){
		String mailPattern = "^[a-zA-Z0-9]+[a-zA-Z0-9_.]*@[a-zA-Z0-9_.]+.[a-zA-Z0-9]{2,4}$";
		if(Pattern.matches(mailPattern, custEmail))
			return true;
		else
		  return false;
	}
/*
  ^						#Start of the pattern 
  [a-zA-Z0-9]+     		#Pattern must start with sequence containing minimum of one character that may be a lower case, upper case or digits
  [a-zA-Z0-9_.]*		#Zero or more number of character from the sequence lower case, upper case, underscore or dot
  @						#Must contain a @ special character
  [a-zA-Z0-9_.]+		#Must contain one or more characters from the sequence
  .						#Followed by a dot
  [a-zA-Z0-9]{2,4}		#Must contain minimum of 2 characters and maximum of 6 from the list
  $						#End of the pattern
  Examples of Valid Mail Id:
   	email@domain.com , firstname.lastname@domain.com , email@subdomain.domain.com, email_123@domain.co.jp 
*/
	
	
	@Override
	public boolean validateMobileNumber(long custMob){
		String custMobile = new Long(custMob).toString();
		String mobilePattern = "[0-9]{10}";
		if(Pattern.matches(mobilePattern, custMobile))
			return true;
		else
		  return false;
		
	}
	
	@Override
	public boolean validateName(String custName){
		String namePattern = "[A-Z]([a-z])*{5,20}";
		if(Pattern.matches(namePattern, custName))
			return true;
		else
		  return false;
	}

	@Override
	public boolean confirmPassword(String custPwd, String confirmPwd){
		if(custPwd.equals(confirmPwd))
			return true;
		else
			return false;
	}
	
	@Override
	public boolean validatePAN(String custPAN){
		String panPattern = "[A-Z]{5}[0-9]{4}";
		if(Pattern.matches(panPattern, custPAN))
			return true;
		else
		  return false;
			
	}

	@Override
	public boolean validateTPwd(String custTPwd) {
		String pwdPattern = "((?=.*\\d)(?=.*[a-z])(?=.*[@#$%]).{6,20})";
		if(Pattern.matches(pwdPattern, custTPwd))
			return true;		
		else
			return false;
	}

}
