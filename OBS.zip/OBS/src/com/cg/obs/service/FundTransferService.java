package com.cg.obs.service;

import com.cg.obs.exception.BankException;
//Interface for Fund Transfer Service
public interface FundTransferService {

	public boolean transferToSelf(long debitAcc, long creditAcc, int amt)throws BankException;
}
