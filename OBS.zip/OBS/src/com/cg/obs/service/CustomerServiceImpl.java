package com.cg.obs.service;

import java.util.regex.Pattern;

import com.cg.obs.dao.CustomerDaoImpl;
import com.cg.obs.exception.BankException;
//Contains the Dao Call to Customer Service methods
public class CustomerServiceImpl implements CustomerService {

	CustomerDaoImpl dao;
	
	public CustomerServiceImpl() {
		dao = new CustomerDaoImpl();
	}

	@Override
	public void addCustomer(String custName, String custEmail, String custAddr, String custPAN, long custMob,
			long accId) throws BankException {
		
		dao.addCustomer(custName, custEmail, custAddr, custPAN, custMob, accId);

	}
	

	@Override
	public boolean updateMobile(long accNo, long new_number) throws BankException {
		
		return dao.updateMobile(accNo, new_number);
		
	}

	@Override
	public boolean updateAddress(long accNo, String address) throws BankException {
		return dao.updateAddress(accNo, address);
		
	}

	@Override
	public long getMobile(long accNo) throws BankException {
		return dao.getMobile(accNo);
	}

	@Override
	public String getAddress(long accNo) throws BankException {
		return dao.getAddress(accNo);
	}

}
