package com.cg.obs.util;
//Connection is formed with the database using this class
import java.sql.*;
public class DBUtil {
	
	public static Connection getconnection()
	{
		Connection con=null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G";
			String user="Lab2Etrg26";
			String password="lab2eoracle";
			
			
			con= DriverManager.getConnection(url,user,password);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
}
